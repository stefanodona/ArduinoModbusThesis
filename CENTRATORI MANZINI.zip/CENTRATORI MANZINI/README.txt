PROVE ESEGUITE IL 14-06-2024

Ogni campione è stato misurato 5 volte di seguito, da completamente nuovo con intervalli di riposo di 5 minuti tra un campione e l'altro.

I campioni sono:
 - CNT0771454CT-1
 - CNT0771454CT-2
 - CNT0771454CT-3
 - CNT0771454D-1
 - CNT0771454D-2
 - CNT0771454D-3
